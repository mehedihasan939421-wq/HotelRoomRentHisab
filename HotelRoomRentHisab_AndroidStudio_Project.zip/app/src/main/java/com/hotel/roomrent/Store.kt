package com.hotel.roomrent

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object Store {
    private const val PREF = "hotel_room_rent_data"
    private const val KEY = "rooms"

    fun load(context: Context): MutableList<RoomEntry> {
        val raw = context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        val result = mutableListOf<RoomEntry>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                result.add(RoomEntry(o.getLong("id"), o.getString("roomNo"),
                    o.getLong("start"), o.getLong("end"), o.getDouble("rent")))
            }
        } catch (_: Exception) { }
        return result
    }

    fun save(context: Context, rooms: List<RoomEntry>) {
        val arr = JSONArray()
        rooms.forEach {
            arr.put(JSONObject().put("id", it.id).put("roomNo", it.roomNo)
                .put("start", it.startMillis).put("end", it.endMillis).put("rent", it.dailyRent))
        }
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }
}
