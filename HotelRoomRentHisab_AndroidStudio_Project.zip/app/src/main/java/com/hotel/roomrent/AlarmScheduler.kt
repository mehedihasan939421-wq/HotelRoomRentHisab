package com.hotel.roomrent

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build

object AlarmScheduler {
    fun schedule(context: Context, room: RoomEntry) {
        cancel(context, room.id)
        scheduleOne(context, room, room.endMillis - 30L * 60L * 1000L, 0, "৩০ মিনিট বাকি",
            "রুম ${room.roomNo}-এর ভাড়ার সময় ৩০ মিনিটের মধ্যে শেষ হবে।")
        scheduleOne(context, room, room.endMillis, 1, "ভাড়ার মেয়াদ শেষ",
            "রুম ${room.roomNo}-এর ভাড়ার মেয়াদ শেষ হয়েছে।")
    }

    private fun scheduleOne(context: Context, room: RoomEntry, at: Long, type: Int, title: String, message: String) {
        if (at <= System.currentTimeMillis()) return
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            putExtra("title", title); putExtra("message", message); putExtra("roomId", room.id)
        }
        val pi = PendingIntent.getBroadcast(context, requestCode(room.id, type), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !am.canScheduleExactAlarms()) {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
                } else {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
                }
            } else am.setExact(AlarmManager.RTC_WAKEUP, at, pi)
        } catch (_: SecurityException) {
            am.set(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    fun cancel(context: Context, roomId: Long) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        for (type in 0..1) {
            val intent = Intent(context, AlarmReceiver::class.java)
            val pi = PendingIntent.getBroadcast(context, requestCode(roomId, type), intent,
                PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE)
            if (pi != null) am.cancel(pi)
        }
    }

    private fun requestCode(id: Long, type: Int): Int =
        ((id % 1_000_000L) * 2L + type).toInt()
}
