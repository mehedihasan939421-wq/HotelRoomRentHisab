package com.hotel.roomrent

data class RoomEntry(
    val id: Long,
    val roomNo: String,
    val startMillis: Long,
    val endMillis: Long,
    val dailyRent: Double
) {
    fun daysCharged(): Long {
        val duration = (endMillis - startMillis).coerceAtLeast(1L)
        return ((duration + DAY_MS - 1) / DAY_MS).coerceAtLeast(1L)
    }
    fun totalRent(): Double = daysCharged() * dailyRent
    companion object { const val DAY_MS = 24L * 60L * 60L * 1000L }
}
