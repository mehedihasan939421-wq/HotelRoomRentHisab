package com.hotel.roomrent

import android.Manifest
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : android.app.Activity() {
    private lateinit var list: LinearLayout
    private lateinit var summary: TextView
    private val rooms = mutableListOf<RoomEntry>()
    private val dateFormat = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        rooms.addAll(Store.load(this))
        buildUi()
        requestPermissionsIfNeeded()
        rooms.forEach { AlarmScheduler.schedule(this, it) }
        render()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
            setBackgroundColor(0xFFF4F7F6.toInt())
        }
        val heading = TextView(this).apply {
            text = "HOTEL ROOM RENT HISAB"
            textSize = 22f; setTextColor(0xFFFFFFFF.toInt())
            setPadding(16, 20, 16, 20); gravity = Gravity.CENTER
            setBackgroundColor(0xFF153B32.toInt())
        }
        summary = TextView(this).apply {
            textSize = 15f; setTextColor(0xFF153B32.toInt())
            setPadding(8, 14, 8, 14)
        }
        val add = Button(this).apply {
            text = "+ নতুন রুম যোগ করুন"
            setOnClickListener { showEditor(null) }
        }
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(list) }
        root.addView(heading)
        root.addView(summary)
        root.addView(add)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun requestPermissionsIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 101)
        }
        if (Build.VERSION.SDK_INT >= 31) {
            val am = getSystemService(ALARM_SERVICE) as android.app.AlarmManager
            if (!am.canScheduleExactAlarms()) {
                try {
                    startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                        Uri.parse("package:$packageName")))
                } catch (_: Exception) { }
            }
        }
    }

    private fun render() {
        list.removeAllViews()
        val total = rooms.sumOf { it.totalRent() }
        summary.text = "মোট রুম: ${rooms.size}     মোট সম্ভাব্য ভাড়া: ${money(total)}"
        if (rooms.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "এখনো কোনো রুম যোগ করা হয়নি।\nনতুন রুম যোগ করুন বাটনে চাপ দিন।"
                textSize = 16f; setPadding(12, 28, 12, 28)
            })
        }
        rooms.sortedBy { it.endMillis }.forEach { room ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(14, 12, 14, 12)
                setBackgroundColor(0xFFFFFFFF.toInt())
            }
            val now = System.currentTimeMillis()
            val status = when {
                room.endMillis <= now -> "মেয়াদ শেষ"
                room.endMillis <= now + 30 * 60 * 1000L -> "৩০ মিনিটের মধ্যে শেষ"
                else -> "চলমান"
            }
            val color = if (room.endMillis <= now) 0xFFB3261E.toInt()
                else if (room.endMillis <= now + 30 * 60 * 1000L) 0xFFB26A00.toInt()
                else 0xFF176B45.toInt()
            card.addView(TextView(this).apply {
                text = "রুম ${room.roomNo}   •   $status"
                textSize = 18f; setTextColor(color)
            })
            card.addView(TextView(this).apply {
                text = "শুরু: ${dateFormat.format(Date(room.startMillis))}\n" +
                    "শেষ: ${dateFormat.format(Date(room.endMillis))}\n" +
                    "দৈনিক ভাড়া: ${money(room.dailyRent)}\n" +
                    "হিসাবের দিন: ${room.daysCharged()} দিন\n" +
                    "মোট ভাড়া: ${money(room.totalRent())}"
                textSize = 14f; setTextColor(0xFF333333.toInt()); setPadding(0, 8, 0, 8)
            })
            val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            actions.addView(Button(this).apply {
                text = "এডিট"; setOnClickListener { showEditor(room) }
            }, LinearLayout.LayoutParams(0, -2, 1f))
            actions.addView(Button(this).apply {
                text = "ডিলিট"; setOnClickListener { confirmDelete(room) }
            }, LinearLayout.LayoutParams(0, -2, 1f))
            card.addView(actions)
            list.addView(card)
            val gap = View(this); list.addView(gap, LinearLayout.LayoutParams(1, 12))
        }
    }

    private fun showEditor(existing: RoomEntry?) {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(20, 8, 20, 0)
        }
        val roomInput = EditText(this).apply {
            hint = "Room No (যেমন 101)"
            setSingleLine(true); setText(existing?.roomNo ?: "")
        }
        val rentInput = EditText(this).apply {
            hint = "দৈনিক ভাড়া (যেমন 100)"
            inputType = 8194
            setSingleLine(true); setText(existing?.dailyRent?.toString() ?: "")
        }
        var start = existing?.startMillis ?: System.currentTimeMillis()
        var end = existing?.endMillis ?: (start + RoomEntry.DAY_MS)
        val startButton = Button(this)
        val endButton = Button(this)
        fun refreshButtons() {
            startButton.text = "শুরুর তারিখ ও সময়: ${dateFormat.format(Date(start))}"
            endButton.text = "শেষের তারিখ ও সময়: ${dateFormat.format(Date(end))}"
        }
        fun pickDateTime(initial: Long, onPicked: (Long) -> Unit) {
            val cal = java.util.Calendar.getInstance().apply { timeInMillis = initial }
            DatePickerDialog(this, { _, y, m, d ->
                TimePickerDialog(this, { _, h, min ->
                    val picked = java.util.Calendar.getInstance().apply {
                        set(y, m, d, h, min, 0); set(java.util.Calendar.MILLISECOND, 0)
                    }.timeInMillis
                    onPicked(picked); refreshButtons()
                }, cal.get(java.util.Calendar.HOUR_OF_DAY), cal.get(java.util.Calendar.MINUTE), false).show()
            }, cal.get(java.util.Calendar.YEAR), cal.get(java.util.Calendar.MONTH),
                cal.get(java.util.Calendar.DAY_OF_MONTH)).show()
        }
        startButton.setOnClickListener { pickDateTime(start) { start = it } }
        endButton.setOnClickListener { pickDateTime(end) { end = it } }
        refreshButtons()
        panel.addView(TextView(this).apply { text = "রুম নম্বর"; textSize = 13f })
        panel.addView(roomInput)
        panel.addView(startButton)
        panel.addView(endButton)
        panel.addView(TextView(this).apply { text = "দৈনিক ভাড়া"; textSize = 13f })
        panel.addView(rentInput)
        AlertDialog.Builder(this)
            .setTitle(if (existing == null) "নতুন রুম যোগ করুন" else "রুম এডিট করুন")
            .setView(panel)
            .setNegativeButton("বাতিল", null)
            .setPositiveButton("সেভ", null)
            .create().also { dialog ->
                dialog.setOnShowListener {
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                        val roomNo = roomInput.text.toString().trim()
                        val rent = rentInput.text.toString().trim().toDoubleOrNull()
                        when {
                            roomNo.isBlank() -> roomInput.error = "রুম নম্বর দিন"
                            rent == null || rent < 0 -> rentInput.error = "সঠিক ভাড়া লিখুন"
                            end <= start -> Toast.makeText(this, "শেষের সময় শুরুর সময়ের পরে হতে হবে", Toast.LENGTH_LONG).show()
                            else -> {
                                val id = existing?.id ?: System.currentTimeMillis()
                                val updated = RoomEntry(id, roomNo, start, end, rent)
                                if (existing != null) {
                                    val index = rooms.indexOfFirst { it.id == existing.id }
                                    if (index >= 0) rooms[index] = updated
                                } else rooms.add(updated)
                                Store.save(this, rooms)
                                AlarmScheduler.schedule(this, updated)
                                dialog.dismiss(); render()
                            }
                        }
                    }
                }
                dialog.show()
            }
    }

    private fun confirmDelete(room: RoomEntry) {
        AlertDialog.Builder(this).setTitle("রুম মুছে ফেলবেন?")
            .setMessage("রুম ${room.roomNo}-এর তথ্য মুছে যাবে।")
            .setNegativeButton("না", null)
            .setPositiveButton("হ্যাঁ, মুছুন") { _, _ ->
                rooms.removeAll { it.id == room.id }
                Store.save(this, rooms)
                AlarmScheduler.cancel(this, room.id)
                render()
            }.show()
    }

    private fun money(value: Double): String =
        String.format(Locale.getDefault(), "%.2f", value)
}
